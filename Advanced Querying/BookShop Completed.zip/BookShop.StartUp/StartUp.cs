﻿using System;
using System.Linq;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace BookShop
{
    using BookShop.Data;
    using BookShop.Initializer;
    
    public class StartUp
    {
        static void Main()
        {
            //var input = Console.ReadLine();
            using (var db = new BookShopContext())
            {
               var result= GetTotalProfitByCategory(db);
                // DbInitializer.ResetDatabase(db);
                Console.WriteLine(result);
            }
        }

        public static string CountCopiesByAuthor(BookShopContext context)
        {
            var authors = context.Authors.Select(a => new
                {
                    Name = $"{a.FirstName} {a.LastName}",
                    Copies = a.Books.Select(b => b.Copies).Sum()
                })
                .OrderByDescending(a => a.Copies)
                .ToArray();

            var result=new StringBuilder();

            foreach (var author in authors)
            {
                result.Append($"{author.Name} - {author.Copies}" + Environment.NewLine);
            }

            return result.ToString();
        }
        
        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            var categories = input.ToLower().Split();

            var books = context.Books.Where(b => b.BookCategories.Any(bc => categories.Contains(bc.Category.Name.ToLower())))
                .Select(b => b.Title).OrderBy(b => b).ToArray();

            var result = String.Join(Environment.NewLine, books);
            return result;
        }

        public static string GetAuthorNamesEndingIn(BookShopContext context, string input)
        {
            var authors = context.Authors.Where(a => a.FirstName.ToLower()
                    .EndsWith(input.ToLower()))
                .OrderBy(a => a.FirstName)
                .ThenBy(a => a.LastName)
                .Select(a => $"{a.FirstName} {a.LastName}")
                .ToArray();

            var result = String.Join(Environment.NewLine, authors);

            return result;

        }

        public static string GetMostRecentBooks(BookShopContext context)
        {
            var categories = context.Categories
                .OrderBy(c => c.Name)
                .Select(c => new
                {
                    c.Name,
                    Books = c.CategoryBooks.Select(cb => cb.Book).OrderByDescending(b => b.ReleaseDate).Take(3)
                }).ToArray();

            var result =new StringBuilder();

            foreach (var c in categories)
            {
                result.Append($"--{c.Name}" + Environment.NewLine);
                foreach (var b in c.Books)
                {
                    result.Append($"{b.Title} ({b.ReleaseDate.Value.Year})" + Environment.NewLine);
                }
            }

            return result.ToString();
        }

        public static void IncreasePrices(BookShopContext context)
        {
            var books = context.Books
                .Where(b => b.ReleaseDate.Value.Year < 2010).ToArray();

            foreach (var book in books)
            {
                book.Price += 5m;
            }

            context.SaveChanges();
        }

        public static int RemoveBooks(BookShopContext context)
        {
            var books = context.Books.Where(b => b.Copies < 4200);

            var count = books.Count();

            context.Books.RemoveRange(books);

            context.SaveChanges();

            return count;
        }

        public static string GetTotalProfitByCategory(BookShopContext context)
        {
            var categories = context.Categories.Select(c => new
            {
                Name = c.Name,
                Profit = c.CategoryBooks.Select(cb => cb.Book.Copies * cb.Book.Price).Sum()
            }).OrderByDescending(c => c.Profit).ToArray();

            var result=new StringBuilder();

            foreach (var category in categories)
            {
                result.Append($"{category.Name} ${category.Profit:f2}" + Environment.NewLine);
            }

            return result.ToString();
        }
    }
}
